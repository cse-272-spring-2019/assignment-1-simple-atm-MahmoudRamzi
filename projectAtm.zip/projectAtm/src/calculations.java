import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class calculations {
    int c;
    StringBuilder stringBuilder = new StringBuilder();
    Stage stage;
    Scene scene;
    GridPane gridPane = new GridPane();
    mainScreen mainScreen;
    loginScreen loginScreen =new loginScreen(stage);
    public calculations(Stage stage) {
        this.stage = stage;
    }

    public calculations(mainScreen mainScreen) {
        this.mainScreen = mainScreen;
    }

    public boolean isInteger(String input ) { //Pass in string
        try { //Try to make the input into an integer
            Integer.parseInt( input );
            return true; //Return true if it works
        }
        catch( Exception e ) {
            return false; //If it doesn't work return false
        }
    }
    public void prepareScene() {
        Button zero = new Button("0");
        Button one = new Button("1");
        Button two = new Button("2");
        Button three = new Button("3");
        Button four = new Button("4");
        Button five = new Button("5");
        Button six = new Button("6");
        Button seven = new Button("7");
        Button eight = new Button("8");
        Button nine = new Button("9");
        Button enter= new Button("enter");
        enter.setMinSize(50,100);

        TextField amount = new TextField();

        gridPane.add(amount, 1, 0);
        gridPane.add(one, 0, 2);
        gridPane.add(two, 1, 2);
        gridPane.add(three, 2, 2);
        gridPane.add(four, 0, 3);
        gridPane.add(five, 1, 3);
        gridPane.add(six, 2, 3);
        gridPane.add(seven, 0, 4);
        gridPane.add(eight, 1, 4);
        gridPane.add(nine, 2, 4);
        gridPane.add(zero, 1, 5);
        gridPane.add(enter,2,6);

        zero.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stringBuilder.append("0");
                amount.setText(stringBuilder.toString());

            }
        });
        one.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stringBuilder.append("1");
                amount.setText(stringBuilder.toString());

            }
        });
        two.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stringBuilder.append("2");
                amount.setText(stringBuilder.toString());

            }
        });
        three.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stringBuilder.append("3");
                amount.setText(stringBuilder.toString());

            }
        });
        four.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stringBuilder.append("4");
                amount.setText(stringBuilder.toString());

            }
        });
        five.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stringBuilder.append("5");
                amount.setText(stringBuilder.toString());

            }
        });
        six.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stringBuilder.append("6");
                amount.setText(stringBuilder.toString());

            }
        });
        seven.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stringBuilder.append("7");
                amount.setText(stringBuilder.toString());

            }
        });
        eight.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stringBuilder.append("8");
                amount.setText(stringBuilder.toString());

            }
        });
        nine.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stringBuilder.append("9");
                amount.setText(stringBuilder.toString());
            }
        });
try {
    enter.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {

            if ((Boolean) isInteger(stringBuilder.toString())) {
                int x= Integer.parseInt(stringBuilder.toString());

                System.out.println(x);
                System.out.println(loginScreen.inquiry);
                switch (mainScreen.getState()) {
                    case 1:
                        if (x <= loginScreen.inquiry){
                            loginScreen.inquiry=loginScreen.inquiry-x;
                        stage.setScene(mainScreen.getScene());}
                        else amount.setText("wrong or big amount");

                        break;
                    case 2:
                        loginScreen.inquiry=loginScreen.inquiry+x;
                        stage.setScene(mainScreen.getScene());
                        break;
                    default: System.out.println("Sss");
                }
            }
            else amount.setText("ss");
        }
    });
}
catch (NullPointerException e){
System.out.println("ssss");
}
        scene = new Scene(gridPane, 400, 400);

    }
        public Scene getScene () {
            return scene;
        }

        public void setMainScreen (mainScreen mainScreen){
            this.mainScreen = mainScreen;
        }

    }
