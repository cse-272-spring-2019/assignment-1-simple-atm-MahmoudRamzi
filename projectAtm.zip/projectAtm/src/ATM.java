import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.util.Set;

public class ATM extends Application {


    public static void main(String[] args) {

        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {


        primaryStage.setTitle("ATM");
        mainScreen mainScreen =new mainScreen(primaryStage);
calculations calculations=new calculations(primaryStage);
        loginScreen loginScreen= new loginScreen(primaryStage);
        loginScreen.prepareScene();
        mainScreen.prepareScene();
        calculations.prepareScene();
        loginScreen.setMainScreen(mainScreen);
        mainScreen.setMainScreen(calculations);
        calculations.setMainScreen(mainScreen);
        primaryStage.setScene(loginScreen.getScene());

       // Scene scene = new Scene(grid,600,400 );
    primaryStage.show();
    }


}
