import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class mainScreen {
    String ss;

    public void setSs(String ss) {
        this.ss = ss;
    }

    public String getSs() {
        return ss;
    }

    Stage stage;
    GridPane grid = new GridPane();
    Scene scene;
    loginScreen loginScreen=new loginScreen(stage);
    calculations calculations =new calculations(stage);
int state ;

    public void setState(int state) {
        this.state = state;
    }

    public mainScreen(Stage stage){
        this.stage=stage;
    }

    public mainScreen(calculations calculations) {
        this.calculations = calculations;
    }

    public void prepareScene(){
        Button withDraw = new Button("Withdraw");
        Button deposite = new Button("Deposite");
        Button balanceInquiry = new Button("Balance Inquiry");
        Button next = new Button("Next");
        Button prev = new Button("Previous");
        Label transaction = new Label();
        Label money = new Label();
        grid.add(withDraw,0,0);
        grid.add(deposite,2,0);
        grid.add(balanceInquiry,4,0);
        grid.add(next,0,2);
        grid.add(prev,0,4);
        grid.add(transaction,1,3);
        grid.add(money,1,4);
        withDraw.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stage.setScene(calculations.getScene());
                setState(1);
            }
        });
        withDraw.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stage.setScene(calculations.getScene());
                setState(1);
            }
        });
        deposite.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stage.setScene(calculations.getScene());
                setState(2);
            }
        });
        balanceInquiry.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String string=new String();
                string= String.valueOf(loginScreen.inquiry);
                money.setText(string);

            }
        });



        scene=new Scene(grid,600,400);



    }

    public int getState() {
        return state;
    }

    public Scene getScene() {
        return scene;
    }




    public void setMainScreen (calculations calculations){
        this.calculations=calculations;

    }


    }


