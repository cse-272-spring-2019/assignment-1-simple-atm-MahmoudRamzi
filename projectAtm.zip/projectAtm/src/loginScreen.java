import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class loginScreen {
    Stage stage;
    public int inquiry;


    private GridPane grid = new GridPane();
    private Scene scene ;
    private loginAuth log =new loginAuth();
    mainScreen mainScreen;

    public loginScreen(Stage stage) {
        this.stage=stage;
    }




    public void prepareScene() {

        Label userName = new Label("User Name : ");
        Label password = new Label("Passwod : ");
        Label validationLable = new Label();
        Button login = new Button("login");
        TextField userNameT = new TextField();
        PasswordField passwordT = new PasswordField();
        grid.add(userName,0,0);
        grid.add(password,0,1);
        grid.add(userNameT,1,0);
        grid.add(passwordT,1,1);
        grid.add(login,1,2);
        grid.add(validationLable,1,3);

        login.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String username = userNameT.getText();
                String pass= passwordT.getText();
                boolean val = log.validate(username,pass);
                if(val){
                stage.setScene(mainScreen.getScene());
                if(userNameT.getText().equals("mahmoud")){
                    inquiry=5000;
                System.out.println("no");}
                else inquiry=10000;
                }
                else
                validationLable.setText("wrong username or password");

            }
        });

        scene =new Scene(grid,600,400);

    }



    public Scene getScene() {
        return scene  ;
    }

    public void setMainScreen(mainScreen mainScreen) {
        this.mainScreen = mainScreen;
    }

}

