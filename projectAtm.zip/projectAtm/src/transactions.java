import java.util.Set;

public class transactions { public StringBuilder stringggg;
    int i=0;
    public void transactions(   int value ){
        stringggg.append(value);

    }
    public void extract(){
        StringBuilder s=new StringBuilder();
        for (  i = 0, i < 5, ++i ){
s.append(stringggg.subSequence(stringggg.length()-6,stringggg.length()-1));
        }
    }

}
