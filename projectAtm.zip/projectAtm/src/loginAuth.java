import java.util.HashMap;

public class loginAuth {
    HashMap hashMap=new HashMap();




    public loginAuth(){
    hashMap.put("mahmoud","4646");
    hashMap.put("israa","2411");

}
    public boolean validate (String username,String password){
    boolean valid = false;
    String fetchPass= (String)hashMap.get(username);
    if(fetchPass!=null)
        valid=fetchPass.equals(password);
    return valid;
    }


}
